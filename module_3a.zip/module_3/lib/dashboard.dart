import 'package:flutter/material.dart';

import 'package:flutter_application_1/logout.dart';
import 'package:flutter_application_1/main.dart';
import 'package:flutter_application_1/personal_info.dart';

class Dashboard extends StatelessWidget {
  const Dashboard({Key? key}) : super(key: key);
  static const String _title = 'HOME/DASHBOARD';

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: _title,
      home: Scaffold(
        appBar: AppBar(title: const Text(_title)),
        body: const MyStatelessWidget(),
      ),
    );
  }
}

class MyStatelessWidget extends StatelessWidget {
  const MyStatelessWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final ButtonStyle style =
        TextButton.styleFrom(primary: Theme.of(context).colorScheme.onPrimary);
    return Scaffold(
      appBar: AppBar(
        actions: <Widget>[
          TextButton(
            style: style,
            onPressed: () => {
              Navigator.push(
                  context, MaterialPageRoute(builder: (context) => Logout()))
            },
            child: const Text('Log Out'),
          ),
          Container(
              alignment: Alignment.center,
              padding: const EdgeInsets.all(10),
              child: const Text(
                'WELCOME HOME',
                style: TextStyle(fontSize: 20),
              )),
          TextButton(
            style: style,
            onPressed: () => {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => ChangePassword()))
            },
            child: const Text('User Profile'),
          ),
        ],
      ),
    );
  }
}
